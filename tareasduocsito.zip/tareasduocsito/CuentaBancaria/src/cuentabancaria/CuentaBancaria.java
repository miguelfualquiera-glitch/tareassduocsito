/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cuentabancaria;

/**
 *
 * @author AL-Alumno
 */
public class CuentaBancaria {
    
    private double saldo;
    
    public double getSaldo(){
        return saldo;
    }
        
    public void depositar (double monto) {
    if (monto > 0){
        saldo += monto;
    }
    }
    /**
     * @param args the command line arguments
     */
    public static void main (String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria();
        
        cuenta.depositar (5000);
        System.out.println(cuenta.getSaldo());
    }
}